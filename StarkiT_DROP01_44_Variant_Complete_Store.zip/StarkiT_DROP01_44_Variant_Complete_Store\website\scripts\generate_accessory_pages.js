import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const ROOT = path.resolve(__dirname, '..');

await import('../assets/js/catalog-data.js');
const catalog = globalThis.STARKIT_CATALOG;
const accessories = catalog.filter((p) => p.id.startsWith('FT-'));
console.log(`Found ${accessories.length} Fariza's Territory accessories to generate.`);

function escapeHtml(str) {
  return String(str || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

const META_PIXEL = `<!-- Meta Pixel Code -->
  <script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', '1390081606323661');
  fbq('track', 'PageView');
  </script>
  <noscript><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=1390081606323661&ev=PageView&noscript=1" /></noscript>
  <!-- End Meta Pixel Code -->`;

for (const p of accessories) {
  const v = p.variants[0];
  const imgRel = v.gallery[0].url.replace(/^\//, '../');
  const priceFormatted = '৳' + Number(p.price_bdt).toLocaleString('en-BD');
  const waText = encodeURIComponent(
    `Hello StarkiT! I would like to order "${p.name}" (Design ID: ${p.id}, Price: ${priceFormatted}). Cash on Delivery please!`
  );

  const html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <meta name="theme-color" content="#0b090a">
  <meta name="description" content="${escapeHtml(p.copy_en)} Handcrafted in Dhaka. Price ${priceFormatted}. Cash on Delivery nationwide in Bangladesh.">
  <title>${escapeHtml(p.name)} | StarkiT Artisan Accessories</title>
  <link rel="icon" type="image/png" href="../assets/images/starkit-favicon.png">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@500;600;700;800&family=Plus+Jakarta+Sans:wght@400;500;600;700&family=Hind+Siliguri:wght@400;500;600;700&family=JetBrains+Mono:wght@500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../assets/css/styles.css">
  <meta property="og:site_name" content="StarkiT">
  <meta property="og:title" content="${escapeHtml(p.name)} | StarkiT Artisan Accessories">
  <meta property="og:description" content="${escapeHtml(p.copy_en)} Price ${priceFormatted}. Cash on Delivery in Bangladesh.">
  <meta property="og:image" content="${imgRel}">
  <meta property="og:type" content="product">
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="${escapeHtml(p.name)} | StarkiT Artisan Accessories">
  <meta name="twitter:description" content="${escapeHtml(p.copy_en)}">
  <meta name="twitter:image" content="${imgRel}">
  <script>window.STARKIT_BASE = "../";</script>
  <script defer src="../assets/js/store-config.js"></script>
  <script defer src="../assets/js/catalog-data.js"></script>
  <script defer src="../assets/js/vendor/anime.min.js"></script>
  <script defer src="../assets/js/vendor/motion.js"></script>
  <script type="module" src="../assets/js/app.js"></script>
  ${META_PIXEL}
</head>
<body>
  <div class="announcement"><span>StarkiT</span> &middot; Drop 01 &amp; 02 &middot; Cash on Delivery across 64 districts &middot; Order support <a href="tel:01778307704">01778307704</a></div>

  <header class="header">
    <div class="shell nav-inner">
      <a class="brand" href="../index.html" aria-label="StarkiT home">
        <img src="../assets/images/starkit-logo-dark.png" alt="StarkiT" height="36">
      </a>
      <nav class="nav-links" id="mainNav">
        <a href="../index.html">Home</a>
        <a href="../shop.html" class="active">Collection</a>
        <a href="../about.html">Our World</a>
        <a href="../shipping.html">Information</a>
      </nav>
      <div class="nav-actions">
        <button class="icon-btn" type="button" data-open-cart aria-label="Open shopping bag">Bag <span class="count" data-cart-count>0</span></button>
        <button id="menuToggle" aria-label="Toggle menu" aria-controls="mainNav" aria-expanded="false" class="icon-btn menu-toggle" type="button">☰</button>
      </div>
    </div>
  </header>

  <main>
    <div class="shell">
      <div class="crumb"><a href="../index.html">Home</a> / <a href="../shop.html">Collection</a> / <a href="../shop.html">${escapeHtml(p.collection)}</a> / ${escapeHtml(p.name)}</div>
      <div class="detail" data-detail-product="${p.id}">
        <div class="detail-main">
          <div class="detail-photo" id="detailGallery" tabindex="0" role="button" aria-label="Zoom product image">
            <img src="${imgRel}" alt="${escapeHtml(p.name)}" referrerpolicy="no-referrer">
            <span class="view-tag">Handcrafted in Dhaka</span>
          </div>
          <div id="detailThumbs" class="thumbs">
            <button class="thumb active" type="button" data-gallery="front" aria-label="Show front">
              <img loading="lazy" alt="" src="${imgRel}" referrerpolicy="no-referrer">
            </button>
          </div>
          <p class="hint">Tap main image to inspect high-resolution artisan detail.</p>
        </div>

        <div class="detail-info">
          <div class="eyebrow">Fariza&#39;s Territory · ${escapeHtml(p.collection)}</div>
          <h1>${escapeHtml(p.name)}</h1>
          ${p.bengali_name ? `<h2 class="bn" style="font-size:1.12rem;color:var(--mute);margin:4px 0 12px;font-weight:600;">${escapeHtml(p.bengali_name)}</h2>` : ''}
          <span class="smallcaps muted">SKU · <span id="detailSku">${v.sku}</span></span>
          <div class="detail-price" style="margin:16px 0">${priceFormatted}</div>
          <div class="separator"></div>
          <div class="detail-choice"><strong>Artisan Palette</strong><span class="smallcaps muted">${escapeHtml(v.color)}</span></div>
          <div id="detailColors" class="variant-buttons">
            <button class="color-chip selected" type="button" data-variant="${v.sku}">
              <span class="color-dot" style="background:${v.hex}"></span>${escapeHtml(v.color)}
            </button>
          </div>
          <p class="description">${escapeHtml(p.copy_en)}</p>
          ${p.copy_bn ? `<p class="description bn" lang="bn">${escapeHtml(p.copy_bn)}</p>` : ''}
          <div class="separator"></div>
          <div id="detailSize"></div>
          <button id="purchaseBtn" class="btn purchase-btn" type="button" style="width:100%;margin-top:20px;">Add to Bag · ${priceFormatted}</button>
          <p id="purchaseStatus" class="hint">Cash on Delivery nationwide · Authentic handmade piece.</p>
          <div style="margin-top:10px;">
            <a id="whatsappBtn" href="https://wa.me/8801778307704?text=${waText}" target="_blank" rel="noopener noreferrer" class="btn btn-outline" style="width:100%;border-color:#15803d;color:#15803d;">Order via WhatsApp (01778307704)</a>
          </div>

          <div class="specs">
            <div class="spec"><strong>The Design</strong><span>${escapeHtml(p.front_back_detail)}</span></div>
            <div class="spec"><strong>Materials &amp; Craft</strong><span>${escapeHtml(p.fabric_claim)}</span></div>
            <div class="spec"><strong>Sizing &amp; Fit</strong><span>${escapeHtml(p.size_chart)}</span></div>
            <div class="spec"><strong>Origin</strong><span>Dhaka, Bangladesh · Fariza&#39;s Territory Artisan Studio</span></div>
            <div class="spec"><strong>Delivery</strong><span>Dhaka: ৳80 (2–3 Days) · Nationwide: ৳150 (3–5 Days). Free over ৳3,000.</span></div>
            <div class="spec"><strong>Exchange</strong><span>Hassle-free 7-day exchange guarantee.</span></div>
            <div class="spec"><strong>Design ID</strong><span>${p.id}</span></div>
          </div>

          <div class="notice"><strong>Cash on Delivery:</strong> Inspect your parcel upon delivery across all 64 districts. Support line: <strong>01778307704</strong>.</div>
          <p style="margin-top:24px;"><a class="link-arrow" href="../shop.html">← Back to the Full Collection</a></p>
        </div>
      </div>
    </div>
  </main>

  <footer class="footer">
    <div class="shell">
      <div class="footer-top">
        <div>
          <a href="../index.html">
            <img class="footer-logo" src="../assets/images/starkit-logo-transparent.png" alt="StarkiT ستاركيت">
          </a>
          <p class="footer-slogan">Wear your world.</p>
          <p style="max-width:380px;color:rgba(246,244,240,0.72);line-height:1.65;">Dhaka-based streetwear and artisan house created by Nafe Munawer. Built around community, style, and authenticity.</p>
        </div>
        <div>
          <h4>Discover</h4>
          <nav>
            <a href="../shop.html">All Designs</a>
            <a href="../index.html#lookbook">Interactive Lookbook</a>
            <a href="../about.html">Our World</a>
            <a href="../index.html#collection">Drop 01 &amp; 02</a>
          </nav>
        </div>
        <div>
          <h4>Information</h4>
          <nav>
            <a href="../shipping.html">Delivery &amp; Shipping</a>
            <a href="../returns.html">Returns &amp; Exchanges</a>
            <a href="../contact.html">Customer Care</a>
            <a href="../privacy.html">Privacy Policy</a>
            <a href="../terms.html">Terms of Service</a>
            <a href="../admin.html">Admin Portal</a>
          </nav>
        </div>
      </div>
      <div class="footer-bottom">
        <span>© 2026 StarkiT · Founded by Nafe Munawer</span>
        <span>Dhaka, Bangladesh · Cash on Delivery Nationwide</span>
      </div>
    </div>
  </footer>

  <div class="overlay" id="overlay" aria-hidden="true"></div>
  <aside class="drawer" id="cartDrawer" role="dialog" aria-label="Shopping bag" aria-modal="true">
    <div class="drawer-head">
      <div class="drawer-head-brand">
        <img src="../assets/images/starkit-logo-transparent.png" alt="StarkiT">
        <h2>Your Bag</h2>
      </div>
      <button class="close-btn" data-close-cart aria-label="Close bag">×</button>
    </div>
    <div class="drawer-items" id="cartItems"></div>
    <div class="drawer-foot" id="cartFoot" hidden>
      <div class="summary"><span>Subtotal</span><span id="cartSubtotal">৳0</span></div>
      <p class="hint">Delivery fee (Dhaka ৳80 / Outside ৳150) calculated at checkout. Free shipping over ৳3,000.</p>
      <a class="btn" href="../checkout.html">Proceed to Checkout ↗</a>
    </div>
  </aside>

  <div class="lightbox" id="zoom" role="dialog" aria-modal="true" aria-label="Enlarged product image">
    <button type="button" aria-label="Close zoom">Close ×</button>
    <img id="zoomImg" alt="">
  </div>
  <div id="toast" role="status" aria-live="polite" hidden style="position:fixed;bottom:24px;left:50%;transform:translateX(-50%);z-index:110;background:#0b090a;color:#f6f4f0;padding:13px 20px;border-radius:4px;font-weight:600;max-width:95vw;text-align:center;border:1px solid rgba(191,161,119,0.4);box-shadow:0 12px 36px rgba(0,0,0,0.28);"></div>
</body>
</html>`;

  const outPath = path.join(ROOT, 'products', `${p.slug}.html`);
  fs.writeFileSync(outPath, html, 'utf8');
}
console.log('Successfully generated all 35 accessory product detail pages!');
